import type { VirtualScrollerDesignTokens } from "@primeuix/themes/types/virtualscroller";

export default {
  loader: {
    mask: {
      background: "{content.background}",
      color: "{text.muted.color}",
    },
    icon: {
      size: "1.5rem",
    },
  },
} satisfies VirtualScrollerDesignTokens;
