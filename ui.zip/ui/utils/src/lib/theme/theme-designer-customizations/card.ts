import type { CardDesignTokens } from "@primeuix/themes/types/card";

export default {
  root: {
    background: "{content.background}",
    borderRadius: "{border.radius.md}",
    color: "{content.color}",
    shadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1),0 1px 2px -1px rgba(0, 0, 0, 0.1)",
  },
  body: {
    padding: "1.0rem",
    gap: "0.5rem",
  },
  caption: {
    gap: "0.5rem",
  },
  title: {
    fontSize: "1.25rem",
    fontWeight: "500",
  },
  subtitle: {
    color: "{text.muted.color}",
  },
} satisfies CardDesignTokens;
