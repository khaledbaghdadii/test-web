import type { GalleriaDesignTokens } from "@primeuix/themes/types/galleria";

export default {
  root: {
    borderWidth: "1px",
    borderColor: "{content.border.color}",
    borderRadius: "{content.border.radius}",
    transitionDuration: "{transition.duration}",
  },
  navButton: {
    background: "rgba(255, 255, 255, 0.1)",
    hoverBackground: "rgba(255, 255, 255, 0.2)",
    color: "{surface.100}",
    hoverColor: "{surface.0}",
    size: "2.0rem",
    gutter: "0.5rem",
    prev: {
      borderRadius: "50%",
    },
    next: {
      borderRadius: "50%",
    },
    focusRing: {
      width: "{focus.ring.width}",
      style: "{focus.ring.style}",
      color: "{focus.ring.color}",
      offset: "{focus.ring.offset}",
      shadow: "{focus.ring.shadow}",
    },
  },
  navIcon: {
    size: "1.5rem",
  },
  thumbnailsContent: {
    background: "{content.background}",
    padding: "1.0rem 0.25rem",
  },
  thumbnailNavButton: {
    size: "2.5rem",
    borderRadius: "{content.border.radius}",
    gutter: "0.5rem",
    focusRing: {
      width: "{focus.ring.width}",
      style: "{focus.ring.style}",
      color: "{focus.ring.color}",
      offset: "{focus.ring.offset}",
      shadow: "{focus.ring.shadow}",
    },
  },
  thumbnailNavButtonIcon: {
    size: "1.5rem",
  },
  caption: {
    background: "rgba(0, 0, 0, 0.5)",
    color: "{surface.100}",
    padding: "1.0rem",
  },
  indicatorList: {
    gap: "0.5rem",
    padding: "1.0rem",
  },
  indicatorButton: {
    activeBackground: "{primary.color}",
    width: "1.0rem",
    height: "1.0rem",
    borderRadius: "50%",
    focusRing: {
      width: "{focus.ring.width}",
      style: "{focus.ring.style}",
      color: "{focus.ring.color}",
      offset: "{focus.ring.offset}",
      shadow: "{focus.ring.shadow}",
    },
  },
  insetIndicatorList: {
    background: "rgba(0, 0, 0, 0.5)",
  },
  insetIndicatorButton: {
    background: "rgba(255, 255, 255, 0.4)",
    hoverBackground: "rgba(255, 255, 255, 0.6)",
    activeBackground: "rgba(255, 255, 255, 0.9)",
  },
  closeButton: {
    size: "1.5rem",
    gutter: "0.5rem",
    background: "rgba(255, 255, 255, 0.1)",
    hoverBackground: "rgba(255, 255, 255, 0.2)",
    color: "{surface.50}",
    hoverColor: "{surface.0}",
    borderRadius: "50%",
    focusRing: {
      width: "{focus.ring.width}",
      style: "{focus.ring.style}",
      color: "{focus.ring.color}",
      offset: "{focus.ring.offset}",
      shadow: "{focus.ring.shadow}",
    },
  },
  closeButtonIcon: {
    size: "1.5rem",
  },
  colorScheme: {
    light: {
      thumbnailNavButton: {
        hoverBackground: "{surface.100}",
        color: "{surface.600}",
        hoverColor: "{surface.700}",
      },
      indicatorButton: {
        background: "{surface.200}",
        hoverBackground: "{surface.300}",
      },
    },
    dark: {
      thumbnailNavButton: {
        hoverBackground: "{surface.700}",
        color: "{surface.400}",
        hoverColor: "{surface.0}",
      },
      indicatorButton: {
        background: "{surface.700}",
        hoverBackground: "{surface.600}",
      },
    },
  },
} satisfies GalleriaDesignTokens;
