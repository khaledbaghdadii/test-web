import type { ToastDesignTokens } from "@primeuix/themes/types/toast";

export default {
  root: {
    width: "25.0rem",
    borderRadius: "{content.border.radius}",
    borderWidth: "1px",
    transitionDuration: "{transition.duration}",
  },
  icon: {
    size: "1.5rem",
  },
  content: {
    padding: "{overlay.popover.padding}",
    gap: "0.5rem",
  },
  text: {
    gap: "0.5rem",
  },
  summary: {
    fontWeight: "500",
    fontSize: "1rem",
  },
  detail: {
    fontWeight: "500",
    fontSize: "0.875rem",
  },
  closeButton: {
    width: "1.5rem",
    height: "1.5rem",
    borderRadius: "50%",
    focusRing: {
      width: "{focus.ring.width}",
      style: "{focus.ring.style}",
      offset: "{focus.ring.offset}",
    },
  },
  closeIcon: {
    size: "1.5rem",
  },
  colorScheme: {
    light: {
      root: {
        blur: "1.5px",
      },
      info: {
        background: "color-mix(in srgb, {blue.50}, transparent 5%)",
        borderColor: "{blue.200}",
        color: "{blue.600}",
        detailColor: "{surface.700}",
        shadow: "0 4px 8px 0 rgba(2, 5, 10, 0.04)",
        closeButton: {
          hoverBackground: "{blue.100}",
          focusRing: {
            color: "{blue.600}",
            shadow: "0 0 0 0 #00000000",
          },
        },
      },
      success: {
        background: "color-mix(in srgb, {green.50}, transparent 5%)",
        borderColor: "{green.200}",
        color: "{green.600}",
        detailColor: "{surface.700}",
        shadow: "0 4px 8px 0 rgba(1, 8, 4, 0.04)",
        closeButton: {
          hoverBackground: "{green.100}",
          focusRing: {
            color: "{green.600}",
            shadow: "0 0 0 0 #00000000",
          },
        },
      },
      warn: {
        background: "color-mix(in srgb, {amber.50}, transparent 5%)",
        borderColor: "{amber.200}",
        color: "{amber.600}",
        detailColor: "{surface.700}",
        shadow: "0 4px 8px 0 rgba(9, 7, 0, 0.04)",
        closeButton: {
          hoverBackground: "{amber.100}",
          focusRing: {
            color: "{amber.600}",
            shadow: "0 0 0 0 #00000000",
          },
        },
      },
      error: {
        background: "color-mix(in srgb, {red.50}, transparent 5%)",
        borderColor: "{red.200}",
        color: "{red.600}",
        detailColor: "{surface.700}",
        shadow: "0 4px 8px 0 rgba(10, 3, 3, 0.04)",
        closeButton: {
          hoverBackground: "{red.100}",
          focusRing: {
            color: "{red.600}",
            shadow: "0 0 0 0 #00000000",
          },
        },
      },
      secondary: {
        background: "{surface.100}",
        borderColor: "{surface.200}",
        color: "{surface.600}",
        detailColor: "{surface.700}",
        shadow: "0 4px 8px 0 rgba(4, 5, 6, 0.04)",
        closeButton: {
          hoverBackground: "{surface.200}",
          focusRing: {
            color: "{surface.600}",
            shadow: "0 0 0 0 #00000000",
          },
        },
      },
      contrast: {
        background: "{surface.900}",
        borderColor: "{surface.950}",
        color: "{surface.50}",
        detailColor: "{surface.0}",
        shadow: "0 4px 8px 0 rgba(0, 0, 1, 0.04)",
        closeButton: {
          hoverBackground: "{surface.800}",
          focusRing: {
            color: "{surface.50}",
            shadow: "0 0 0 0 #00000000",
          },
        },
      },
    },
    dark: {
      root: {
        blur: "10px",
      },
      info: {
        background: "color-mix(in srgb, {blue.500}, transparent 84%)",
        borderColor: "color-mix(in srgb, {blue.700}, transparent 64%)",
        color: "{blue.500}",
        detailColor: "{surface.0}",
        shadow: "0 4px 8px 0 rgba(2, 5, 10, 0.04)",
        closeButton: {
          hoverBackground: "rgba(255, 255, 255, 0.05)",
          focusRing: {
            color: "{blue.500}",
            shadow: "none",
          },
        },
      },
      success: {
        background: "color-mix(in srgb, {green.500}, transparent 84%)",
        borderColor: "color-mix(in srgb, {green.700}, transparent 64%)",
        color: "{green.500}",
        detailColor: "{surface.0}",
        shadow: "0 4px 8px 0 rgba(1, 8, 4, 0.04)",
        closeButton: {
          hoverBackground: "rgba(255, 255, 255, 0.05)",
          focusRing: {
            color: "{green.500}",
            shadow: "none",
          },
        },
      },
      warn: {
        background: "color-mix(in srgb, {amber.500}, transparent 84%)",
        borderColor: "color-mix(in srgb, {amber.700}, transparent 64%)",
        color: "{amber.500}",
        detailColor: "{surface.0}",
        shadow: "0 4px 8px 0 rgba(9, 7, 0, 0.04)",
        closeButton: {
          hoverBackground: "rgba(255, 255, 255, 0.05)",
          focusRing: {
            color: "{amber.500}",
            shadow: "none",
          },
        },
      },
      error: {
        background: "color-mix(in srgb, {red.500}, transparent 84%)",
        borderColor: "color-mix(in srgb, {red.700}, transparent 64%)",
        color: "{red.500}",
        detailColor: "{surface.0}",
        shadow: "0 4px 8px 0 rgba(10, 3, 3, 0.04)",
        closeButton: {
          hoverBackground: "rgba(255, 255, 255, 0.05)",
          focusRing: {
            color: "{red.500}",
            shadow: "none",
          },
        },
      },
      secondary: {
        background: "{surface.800}",
        borderColor: "{surface.700}",
        color: "{surface.300}",
        detailColor: "{surface.0}",
        shadow: "0 4px 8px 0 rgba(4, 5, 6, 0.04)",
        closeButton: {
          hoverBackground: "{surface.700}",
          focusRing: {
            color: "{surface.300}",
            shadow: "none",
          },
        },
      },
      contrast: {
        background: "{surface.0}",
        borderColor: "{surface.100}",
        color: "{surface.950}",
        detailColor: "{surface.950}",
        shadow: "0 4px 8px 0 rgba(0, 0, 1, 0.04)",
        closeButton: {
          hoverBackground: "{surface.100}",
          focusRing: {
            color: "{surface.950}",
            shadow: "none",
          },
        },
      },
    },
  },
} satisfies ToastDesignTokens;
