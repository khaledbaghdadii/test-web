import type { StepperDesignTokens } from "@primeuix/themes/types/stepper";

export default {
  root: {
    transitionDuration: "{transition.duration}",
  },
  separator: {
    background: "{content.border.color}",
    activeBackground: "{primary.color}",
    margin: "0.0rem 0.0rem 0.0rem 1.0rem",
    size: "2px",
  },
  step: {
    padding: "0.5rem",
    gap: "1.0rem",
  },
  stepHeader: {
    padding: "0",
    borderRadius: "{content.border.radius}",
    focusRing: {
      width: "{focus.ring.width}",
      style: "{focus.ring.style}",
      color: "{focus.ring.color}",
      offset: "{focus.ring.offset}",
      shadow: "{focus.ring.shadow}",
    },
    gap: "0.5rem",
  },
  stepTitle: {
    color: "{text.muted.color}",
    activeColor: "{primary.color}",
    fontWeight: "500",
  },
  stepNumber: {
    background: "{content.background}",
    activeBackground: "{content.background}",
    borderColor: "{content.border.color}",
    activeBorderColor: "{content.border.color}",
    color: "{text.muted.color}",
    activeColor: "{primary.color}",
    size: "2.0rem",
    fontSize: "1.143rem",
    fontWeight: "500",
    borderRadius: "50%",
    shadow: "0 0.5px 0 0 rgba(0, 0, 0, 0.06),0 1px 1px 0 rgba(0, 0, 0, 0.12)",
  },
  steppanels: {
    padding: "0.75rem 0.5rem 1.0rem 0.5rem",
  },
  steppanel: {
    background: "{content.background}",
    color: "{content.color}",
    padding: "0",
    indent: "1.0rem",
  },
} satisfies StepperDesignTokens;
