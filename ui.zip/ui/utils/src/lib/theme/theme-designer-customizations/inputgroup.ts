import type { InputGroupDesignTokens } from "@primeuix/themes/types/inputgroup";

export default {
  addon: {
    background: "{form.field.background}",
    borderColor: "{form.field.border.color}",
    color: "{form.field.icon.color}",
    borderRadius: "{form.field.border.radius}",
    padding: "0.5rem",
    minWidth: "2.0rem",
  },
} satisfies InputGroupDesignTokens;
