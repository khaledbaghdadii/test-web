import { render, screen, waitFor } from "@testing-library/angular";
import { MockComponent, ngMocks } from "ng-mocks";
import { BuildAndTestTestSectionComponent } from "./build-and-test-test-section.component";
import { BuildAndTestProcessStateUpdaterService } from "@mxevolve/domains/business-process/data-access";
import { ScenarioRunsComponent } from "@mxevolve/domains/test/widget";
import {
  ConfigAuditButtonComponent,
  EnvironmentStatusPanelComponent,
} from "@mxevolve/domains/environment/widget";
import { SCENARIO_EXECUTION_GROUP_PERMISSION_WARNING_MESSAGE } from "../scenario-execution-group-permission-warning-message";

const MOCK_IMPORTS = [
  MockComponent(ScenarioRunsComponent),
  MockComponent(ConfigAuditButtonComponent),
  MockComponent(EnvironmentStatusPanelComponent),
];

const mockStateUpdater = {
  reloadProcessDetails: jest.fn(),
};

async function renderComponent(
  inputs: Partial<{
    projectId: string;
    processId: string;
    environmentId: string;
  }> = {}
) {
  return render(BuildAndTestTestSectionComponent, {
    imports: MOCK_IMPORTS,
    inputs: { projectId: "proj-001", processId: "proc-001", ...inputs },
    componentProviders: [
      {
        provide: BuildAndTestProcessStateUpdaterService,
        useValue: mockStateUpdater,
      },
    ],
  });
}

describe("BuildAndTestTestSectionComponent", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("renders the Test panel header and the TPK Results heading", async () => {
    await renderComponent();

    await waitFor(() => expect(screen.getByText("Test")).toBeTruthy());
    expect(screen.getByText("TPK Results")).toBeTruthy();
  });

  it("wires the scenario-runs widget with the build-and-test context and warning map", async () => {
    const { fixture } = await renderComponent();

    await waitFor(() =>
      expect(document.querySelector("mxevolve-scenario-runs")).toBeTruthy()
    );

    const scenarioRuns = ngMocks.find(fixture, ScenarioRunsComponent);
    expect(scenarioRuns.componentInstance.projectId).toBe("proj-001");
    expect(scenarioRuns.componentInstance.contextId).toBe("proc-001");
    expect(scenarioRuns.componentInstance.subContextId).toBe("BUILD_AND_TEST");
    expect(scenarioRuns.componentInstance.warningMessageMap).toEqual(
      SCENARIO_EXECUTION_GROUP_PERMISSION_WARNING_MESSAGE
    );
  });

  it("reloads the execution when a scenario changes", async () => {
    const { fixture } = await renderComponent();

    await waitFor(() =>
      expect(document.querySelector("mxevolve-scenario-runs")).toBeTruthy()
    );

    ngMocks
      .find(fixture, ScenarioRunsComponent)
      .componentInstance.scenarioChanged.emit();

    expect(mockStateUpdater.reloadProcessDetails).toHaveBeenCalledWith(
      "proc-001",
      "proj-001"
    );
  });

  describe("environment bar", () => {
    it("does not render the environment status panel when no environment id is provided", async () => {
      await renderComponent();

      await waitFor(() => expect(screen.getByText("Test")).toBeTruthy());
      expect(
        document.querySelector("mxevolve-environment-status-panel")
      ).toBeNull();
    });

    it("renders the environment status panel with the Config Audit action when an environment id is provided", async () => {
      await renderComponent({ environmentId: "env-001" });

      await waitFor(() =>
        expect(
          document.querySelector("mxevolve-environment-status-panel")
        ).toBeTruthy()
      );
      expect(
        document.querySelector("mxevolve-config-audit-button")
      ).toBeTruthy();
    });
  });
});
