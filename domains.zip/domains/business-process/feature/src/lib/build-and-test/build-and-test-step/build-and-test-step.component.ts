import { Component, computed, inject, input } from "@angular/core";
import { Message } from "primeng/message";
import { BuildAndTestProcessStateUpdaterService } from "@mxevolve/domains/business-process/data-access";
import {
  StageContainerComponent,
  BusinessProcessContentContainerComponent,
} from "@mxevolve/domains/business-process/ui";
import { MxevolveIllustrationComponent } from "@mxevolve/shared/ui/primitive";
import type { StepStatus } from "@mxevolve/shared/ui/primitive";
import type { BuildAndTestProcessExecution } from "@mxevolve/domains/business-process/util";
import { BuildAndTestBuildSectionComponent } from "./build-and-test-build-section/build-and-test-build-section.component";
import { BuildAndTestTestSectionComponent } from "./build-and-test-test-section/build-and-test-test-section.component";

/**
 * Build & Test step body.
 *
 * Mirrors the legacy `mxflow-build-and-test-stage` section order:
 *   error alert -> loading illustration -> cherry-pick alert ->
 *   Build panel -> Technical Reseed -> Test panel -> Merge action.
 *
 * Story A delivers the shell with placeholder panels; Build/Test/Reseed/Merge
 * content is implemented in Stories B and C.
 */
@Component({
  selector: "mxevolve-build-and-test-step",
  templateUrl: "./build-and-test-step.component.html",
  imports: [
    Message,
    MxevolveIllustrationComponent,
    StageContainerComponent,
    BusinessProcessContentContainerComponent,
    BuildAndTestBuildSectionComponent,
    BuildAndTestTestSectionComponent,
  ],
  providers: [BuildAndTestProcessStateUpdaterService],
  host: {
    style: "display: contents;",
  },
})
export class BuildAndTestStepComponent {
  readonly execution = input.required<BuildAndTestProcessExecution>();
  readonly stageStatus = input.required<StepStatus>();

  private readonly stateUpdater = inject(BuildAndTestProcessStateUpdaterService);

  private readonly stage = computed(() => this.execution().buildAndTestStage);

  readonly projectId = computed(() => this.execution().projectId);
  readonly processId = computed(() => this.execution().id);

  readonly errorMessage = computed(() => this.stage().errorMessage);

  readonly readyForBuildAndTest = computed(
    () => this.stage().readyForBuildAndTest ?? false
  );

  readonly cherryPickRunning = computed(
    () => this.stage().cherryPickRunning ?? false
  );

  readonly cherryPickFailed = computed(
    () => this.stage().cherryPickFailed ?? false
  );

  readonly temporaryBranchName = computed(
    () => this.execution().input.configurationBranchName
  );

  readonly cherryPickFailedMessage = computed(
    () =>
      `Cherry-pick could not be completed automatically. Please manually cherry-pick your commits to the branch '${this.temporaryBranchName()}' and then click 'Proceed to the Next Step' to open a merge request.`
  );

  /** Build Environment is hidden when the run skips environment deployment. */
  readonly showEnvironmentDetails = computed(
    () => !this.execution().input.buildEnvironment.skipEnvironmentDeployment
  );

  /** Jira/user story ids the run is working on. */
  readonly storyIds = computed(() => this.execution().input.userStoryIds ?? []);

  /** Technical Reseed section is conditional on a reseed execution group. */
  readonly showTechnicalReseed = computed(
    () => !!this.stage().technicalReseedExecutionGroupId
  );

  reloadExecution(): void {
    this.stateUpdater.reloadProcessDetails(
      this.execution().id,
      this.execution().projectId
    );
  }
}
