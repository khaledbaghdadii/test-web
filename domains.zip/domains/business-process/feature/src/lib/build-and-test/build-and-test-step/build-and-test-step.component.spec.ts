import { render, screen, waitFor } from "@testing-library/angular";
import { MockComponent } from "ng-mocks";
import { BuildAndTestStepComponent } from "./build-and-test-step.component";
import { BuildAndTestBuildSectionComponent } from "./build-and-test-build-section/build-and-test-build-section.component";
import { BuildAndTestTestSectionComponent } from "./build-and-test-test-section/build-and-test-test-section.component";
import { BuildAndTestProcessStateUpdaterService } from "@mxevolve/domains/business-process/data-access";
import {
  BuildAndTestProcessExecution,
  BuildAndTestSourceType,
  ExecutionStatus,
  StageStatus,
} from "@mxevolve/domains/business-process/util";
import { MxevolveIllustrationComponent } from "@mxevolve/shared/ui/primitive";

const MOCK_IMPORTS = [
  MockComponent(MxevolveIllustrationComponent),
  MockComponent(BuildAndTestBuildSectionComponent),
  MockComponent(BuildAndTestTestSectionComponent),
];

const mockStateUpdater = {
  reloadProcessDetails: jest.fn(),
};

function buildStage(
  overrides: Partial<BuildAndTestProcessExecution["buildAndTestStage"]> = {}
): BuildAndTestProcessExecution["buildAndTestStage"] {
  return {
    name: "build-and-test",
    route: "build-and-test",
    status: StageStatus.PENDING_INPUT,
    readyForBuildAndTest: true,
    cherryPickRunning: false,
    cherryPickFailed: false,
    ...overrides,
  } as BuildAndTestProcessExecution["buildAndTestStage"];
}

function buildExecution(
  buildAndTestStageOverrides: Partial<
    BuildAndTestProcessExecution["buildAndTestStage"]
  > = {},
  inputOverrides: Partial<BuildAndTestProcessExecution["input"]> = {}
): BuildAndTestProcessExecution {
  return {
    id: "execution-1",
    projectId: "project-1",
    name: "CI Run",
    status: ExecutionStatus.RUNNING,
    definitionId: "def-1",
    definitionName: "definition-name",
    familyName: "Build & Test Process",
    processName: "Configuration Build & Test",
    supportsResourceManagement: false,
    hasPredefinedMergeRequestInputs: false,
    ciVersion: 2,
    notificationsRecipients: [],
    owner: "owner",
    source: { id: "source-1", type: BuildAndTestSourceType.USER },
    input: {
      repositoryId: "repo-1",
      configurationBranchName: "feature/temp-branch",
      configurationParentBranch: "main",
      userStoryIds: ["US-1"],
      buildAndTestInfraGroup: "test-env-infra",
      buildEnvironmentInfraGroup: "build-env-infra",
      buildEnvironment: {
        skipEnvironmentDeployment: false,
        scenarioDefinitionId: "scenario-1",
      },
      ...inputOverrides,
    },
    createBranchStage: {
      name: "create-branch",
      route: "create-branch",
      status: StageStatus.PASSED,
    },
    prepareBuildStage: {
      name: "prepare-build",
      route: "prepare-build",
      status: StageStatus.PASSED,
    },
    buildAndTestStage: buildStage(buildAndTestStageOverrides),
    integrateChangesStage: {
      name: "integrate-changes",
      route: "integrate-changes",
      status: StageStatus.NOT_STARTED,
    },
  } as BuildAndTestProcessExecution;
}

async function renderComponent(execution: BuildAndTestProcessExecution) {
  return render(BuildAndTestStepComponent, {
    imports: MOCK_IMPORTS,
    inputs: { execution, stageStatus: "active" },
    componentProviders: [
      {
        provide: BuildAndTestProcessStateUpdaterService,
        useValue: mockStateUpdater,
      },
    ],
  });
}

describe("BuildAndTestStepComponent", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe("error state", () => {
    it("renders the error alert when the stage has an error message", async () => {
      await renderComponent(
        buildExecution({ errorMessage: "Build failed badly" })
      );

      await waitFor(() =>
        expect(screen.getByText("Build failed badly")).toBeTruthy()
      );
    });

    it("hides the loading illustration when there is an error", async () => {
      await renderComponent(
        buildExecution({
          errorMessage: "Build failed badly",
          readyForBuildAndTest: false,
        })
      );

      await waitFor(() =>
        expect(screen.getByText("Build failed badly")).toBeTruthy()
      );
      expect(document.querySelector("mxevolve-illustration")).toBeNull();
    });
  });

  describe("loading state", () => {
    it("renders the loading illustration when not ready for build and test", async () => {
      await renderComponent(
        buildExecution({ readyForBuildAndTest: false })
      );

      await waitFor(() =>
        expect(document.querySelector("mxevolve-illustration")).toBeTruthy()
      );
      expect(
        screen.getByText(
          "The step is currently loading. Please refresh the page for the latest updates."
        )
      ).toBeTruthy();
    });

    it("hides the panels while loading", async () => {
      await renderComponent(
        buildExecution({ readyForBuildAndTest: false })
      );

      await waitFor(() =>
        expect(document.querySelector("mxevolve-illustration")).toBeTruthy()
      );
      expect(
        document.querySelector("mxevolve-build-and-test-build-section")
      ).toBeNull();
      expect(
        document.querySelector("mxevolve-build-and-test-test-section")
      ).toBeNull();
    });
  });

  describe("cherry-pick alert", () => {
    it("renders the cherry-pick running alert with the legacy text", async () => {
      await renderComponent(
        buildExecution({ cherryPickRunning: true })
      );

      await waitFor(() =>
        expect(
          screen.getByText(
            "Automatic cherry picking is in progress. Please refresh the page for the latest update."
          )
        ).toBeTruthy()
      );
    });

    it("renders the cherry-pick failed alert with the legacy text and branch name", async () => {
      await renderComponent(
        buildExecution({ cherryPickRunning: false, cherryPickFailed: true })
      );

      await waitFor(() =>
        expect(
          screen.getByText(
            "Cherry-pick could not be completed automatically. Please manually cherry-pick your commits to the branch 'feature/temp-branch' and then click 'Proceed to the Next Step' to open a merge request."
          )
        ).toBeTruthy()
      );
    });

    it("does not render any cherry-pick alert when both flags are false", async () => {
      await renderComponent(buildExecution());

      await waitFor(() =>
        expect(
          document.querySelector("mxevolve-build-and-test-build-section")
        ).toBeTruthy()
      );
      expect(
        screen.queryByText(/Automatic cherry picking is in progress/)
      ).toBeNull();
      expect(
        screen.queryByText(/Cherry-pick could not be completed automatically/)
      ).toBeNull();
    });
  });

  describe("panels (ready state)", () => {
    it("renders the build section, test section and merge action when ready", async () => {
      await renderComponent(buildExecution());

      await waitFor(() =>
        expect(
          document.querySelector("mxevolve-build-and-test-build-section")
        ).toBeTruthy()
      );
      expect(
        document.querySelector("mxevolve-build-and-test-test-section")
      ).toBeTruthy();
      expect(screen.getByTestId("merge-action-stub")).toBeTruthy();
    });

    it("renders the build section regardless of environment deployment being skipped", async () => {
      await renderComponent(
        buildExecution(
          {},
          {
            buildEnvironment: {
              skipEnvironmentDeployment: true,
              scenarioDefinitionId: "scenario-1",
            },
          }
        )
      );

      await waitFor(() =>
        expect(
          document.querySelector("mxevolve-build-and-test-build-section")
        ).toBeTruthy()
      );
    });

    it("shows the technical reseed stub only when a reseed execution group is present", async () => {
      await renderComponent(
        buildExecution({ technicalReseedExecutionGroupId: "reseed-group-1" })
      );

      await waitFor(() =>
        expect(screen.getByTestId("technical-reseed-stub")).toBeTruthy()
      );
    });

    it("hides the technical reseed stub when there is no reseed execution group", async () => {
      await renderComponent(buildExecution());

      await waitFor(() =>
        expect(
          document.querySelector("mxevolve-build-and-test-build-section")
        ).toBeTruthy()
      );
      expect(screen.queryByTestId("technical-reseed-stub")).toBeNull();
    });
  });
});
