import { render, screen, waitFor } from "@testing-library/angular";
import { MockComponent } from "ng-mocks";
import { BuildAndTestBuildSectionComponent } from "./build-and-test-build-section.component";
import { EnvironmentStatus } from "@mxevolve/domains/environment/util";
import {
  EnvironmentStatusPanelComponent,
  OpenConfigEditorButtonComponent,
} from "@mxevolve/domains/environment/widget";

const MOCK_IMPORTS = [
  MockComponent(EnvironmentStatusPanelComponent),
  MockComponent(OpenConfigEditorButtonComponent),
];

async function renderComponent(
  inputs: Partial<{
    projectId: string;
    storyIds: string[];
    environmentId: string;
    automerge: boolean;
    environmentStatus: EnvironmentStatus;
  }> = {}
) {
  return render(BuildAndTestBuildSectionComponent, {
    imports: MOCK_IMPORTS,
    inputs: { projectId: "proj-001", ...inputs },
  });
}

describe("BuildAndTestBuildSectionComponent", () => {
  it("renders the Build panel header", async () => {
    await renderComponent();

    await waitFor(() => expect(screen.getByText("Build")).toBeTruthy());
  });

  describe("story chips", () => {
    it("renders a chip per story id", async () => {
      await renderComponent({ storyIds: ["VAL-125", "VAL-127"] });

      await waitFor(() =>
        expect(
          screen.getByText("You are working on the following story")
        ).toBeTruthy()
      );
      expect(screen.getByText("VAL-125")).toBeTruthy();
      expect(screen.getByText("VAL-127")).toBeTruthy();
    });

    it("does not render the story section when there are no story ids", async () => {
      await renderComponent({ storyIds: [] });

      await waitFor(() => expect(screen.getByText("Build")).toBeTruthy());
      expect(
        screen.queryByText("You are working on the following story")
      ).toBeNull();
    });
  });

  describe("environment bar", () => {
    it("does not render the environment status panel when no environment id is provided", async () => {
      await renderComponent();

      await waitFor(() => expect(screen.getByText("Build")).toBeTruthy());
      expect(
        document.querySelector("mxevolve-environment-status-panel")
      ).toBeNull();
    });

    it("renders the environment status panel with the Open Config Editor action when an environment id is provided", async () => {
      await renderComponent({ environmentId: "env-001" });

      await waitFor(() =>
        expect(
          document.querySelector("mxevolve-environment-status-panel")
        ).toBeTruthy()
      );
      expect(
        document.querySelector("mxevolve-open-config-editor-button")
      ).toBeTruthy();
    });

    it("hides the Open Config Editor action in automerge mode", async () => {
      await renderComponent({ environmentId: "env-001", automerge: true });

      await waitFor(() =>
        expect(
          document.querySelector("mxevolve-environment-status-panel")
        ).toBeTruthy()
      );
      expect(
        document.querySelector("mxevolve-open-config-editor-button")
      ).toBeNull();
    });
  });
});
