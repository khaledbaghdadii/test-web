import { Component, computed, input } from "@angular/core";
import { Chip } from "primeng/chip";
import { EnvironmentStatus } from "@mxevolve/domains/environment/util";
import {
  EnvironmentStatusPanelComponent,
  OpenConfigEditorButtonComponent,
} from "@mxevolve/domains/environment/widget";
import { BusinessProcessContentContainerComponent } from "@mxevolve/domains/business-process/ui";

/**
 * Build panel of the Build & Test step.
 *
 * Renders the Jira story chips ("You are working on the following story") from
 * the run input, and — when an environment id is available — the shared
 * environment status bar with the Open Config Editor action projected into its
 * [extraActions] slot (Story A's slot).
 *
 * NOTE: `environmentId` is optional because the VAL-26634
 * `BuildAndTestProcessExecution` model does not yet expose the build
 * environment id (legacy resolves it indirectly from a scenario execution). The
 * env bar renders only once that id is threaded through the data-access lib.
 * The Repush-latest-TPK and TPK-Details actions likewise depend on scm/test
 * data not present in the current model and are intentionally not yet wired —
 * flagged in the PR description.
 */
@Component({
  selector: "mxevolve-build-and-test-build-section",
  templateUrl: "./build-and-test-build-section.component.html",
  imports: [
    Chip,
    EnvironmentStatusPanelComponent,
    OpenConfigEditorButtonComponent,
    BusinessProcessContentContainerComponent,
  ],
  host: {
    style: "display: contents;",
  },
})
export class BuildAndTestBuildSectionComponent {
  readonly projectId = input.required<string>();
  /** Jira/user story ids from the run input (e.g. ["VAL-125", "VAL-127"]). */
  readonly storyIds = input<string[]>([]);
  /** Optional until the build environment id is threaded through the model. */
  readonly environmentId = input<string>();
  /** Hide the Open Config Editor action in automerge runs (parent decides). */
  readonly automerge = input<boolean>(false);
  /** Environment status, used to enable/disable the Open Config Editor action. */
  readonly environmentStatus = input<EnvironmentStatus>(
    EnvironmentStatus.READY
  );

  readonly hasStories = computed(() => this.storyIds().length > 0);
  readonly showConfigEditor = computed(() => !this.automerge());
}
