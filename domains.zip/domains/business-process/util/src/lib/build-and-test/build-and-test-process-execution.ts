import { ExecutionStatus } from "../execution-status";
import { Stage } from "../stage";

export interface BuildAndTestProcessExecution {
  readonly id: string;
  readonly name: string;
  readonly projectId: string;
  readonly definitionId: string;
  readonly definitionName: string;
  readonly familyName: string;
  readonly processName: string;
  readonly description?: string;
  readonly owner: string;
  readonly notificationsRecipients?: string[];
  readonly errorMessage?: string;
  readonly startDate?: string;
  readonly endDate?: string;
  readonly expiryDate?: string;
  readonly supportsResourceManagement: boolean;
  readonly hasPredefinedMergeRequestInputs: boolean;
  readonly ciVersion: number;
  readonly source: BuildAndTestSource;
  readonly status: ExecutionStatus;
  readonly input: BuildAndTestProcessExecutionInput;
  readonly createBranchStage: BuildAndTestProcessStage;
  readonly prepareBuildStage: BuildAndTestProcessStage;
  readonly buildAndTestStage: BuildAndTestProcessStage;
  readonly integrateChangesStage: BuildAndTestProcessStage;
}

export interface BuildAndTestProcessExecutionInput {
  readonly repositoryId: string;
  readonly configurationBranchName: string;
  readonly configurationParentBranch: string;
  readonly userStoryIds: string[];
  readonly buildAndTestInfraGroup: string;
  readonly buildEnvironmentInfraGroup: string;
  readonly buildEnvironment: BuildAndTestProcessBuildEnvironmentInput;
}

export interface BuildAndTestProcessBuildEnvironmentInput {
  readonly skipEnvironmentDeployment: boolean;
  readonly scenarioDefinitionId: string;
}

export interface BuildAndTestProcessStage extends Stage {
  readonly route: string;
  readonly developmentId?: string;
  // Build & Test stage-specific fields (additive — populated only on buildAndTestStage).
  readonly readyForBuildAndTest?: boolean;
  readonly cherryPickRunning?: boolean;
  readonly cherryPickFailed?: boolean;
  readonly technicalReseedExecutionGroupId?: string;
  readonly scenarioExecutionGroup?: string;
}

export interface BuildAndTestSource {
  readonly id: string;
  readonly type: BuildAndTestSourceType;
}

export enum BuildAndTestSourceType {
  BUSINESS_PROCESS = "BUSINESS_PROCESS",
  USER = "USER",
}
