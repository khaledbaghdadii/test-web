const ModuleFederationPlugin = require('webpack/lib/container/ModuleFederationPlugin');
const mf = require('@angular-architects/module-federation/webpack');
const path = require('path');
const share = mf.share;
const monacoAssetRules = require('../../tools/webpack/monaco.rules');

/**
 * We use the NX_TSCONFIG_PATH environment variable when using the @nx/angular:webpack-browser
 * builder as it will generate a temporary tsconfig file which contains any required remappings of
 * shared libraries.
 * A remapping will occur when a library is buildable, as webpack needs to know the location of the
 * built files for the buildable library.
 * This NX_TSCONFIG_PATH environment variable is set by the @nx/angular:webpack-browser and it contains
 * the location of the generated temporary tsconfig file.
 */
const tsConfigPath = process.env.NX_TSCONFIG_PATH ?? path.join(__dirname, '../../tsconfig.base.json');

const workspaceRootPath = path.join(__dirname, '../../');
const sharedMappings = new mf.SharedMappings();
sharedMappings.register(
    tsConfigPath,
    [
        '@mxflow/core/auth',
        '@mxflow/feature-flags',
        '@mxflow/core/analytics-tracker'
    ],
    workspaceRootPath
);

module.exports = {
    output: {
        uniqueName: 'ci-process-mfe',
        publicPath: 'auto',
    },
    optimization: {
        runtimeChunk: false,
    },
    experiments: {
        outputModule: true,
    },
    resolve: {
        alias: {
            ...sharedMappings.getAliases(),
        },
    },
    module: {
    rules: [...monacoAssetRules(workspaceRootPath)],
  },
  plugins: [
        new ModuleFederationPlugin({
            name: 'ci-process-mfe',
            filename: 'remoteEntry.js',
            exposes: {
                './Module': 'apps/ci-process-mfe/src/app/ci-process/ci-process.module.ts',
            },
            shared: share({
                '@angular/core': {
                    singleton: true,
                    strictVersion: true,
                    requiredVersion: 'auto',
                    includeSecondaries: true
                },
                '@angular/common': {
                    singleton: true,
                    strictVersion: true,
                    requiredVersion: 'auto',
                    includeSecondaries: true
                },
                '@angular/common/http': {
                    singleton: true,
                    strictVersion: true,
                    requiredVersion: 'auto',
                    includeSecondaries: true,
                },
                '@angular/router': {
                    singleton: true,
                    strictVersion: true,
                    requiredVersion: 'auto',
                    includeSecondaries: true
                },
                'primeng/api': {
                    singleton: true,
                    strictVersion: true,
                    requiredVersion: 'auto',
                    includeSecondaries: true,
                },
                '@ngrx/store-devtools': {
                    singleton: true,
                    strictVersion: true,
                    requiredVersion: 'auto',
                    includeSecondaries: true,
                },
                '@ngrx/effects': {
                    singleton: true,
                    strictVersion: true,
                    requiredVersion: 'auto',
                    includeSecondaries: true,
                },
                '@ngrx/store': {
                    singleton: true,
                    strictVersion: true,
                    requiredVersion: 'auto',
                    includeSecondaries: true,
                },
                rxjs: {
                    singleton: true,
                    strictVersion: true,
                    requiredVersion: 'auto',
                    includeSecondaries: true
                },
                ...sharedMappings.getDescriptors(),
            }),
            library: {
                type: 'module',
            },
        }),
        sharedMappings.getPlugin(),
    ],
};
