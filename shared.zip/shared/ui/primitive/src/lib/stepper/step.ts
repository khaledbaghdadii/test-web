export type StepStatus =
  | "active"
  | "inactive"
  | "completed"
  | "on-hold"
  | "failed"
  | "skipped";

export interface StepDefinition {
  id: string;
  title: string;
  status: StepStatus;
  tooltip?: string;
}
