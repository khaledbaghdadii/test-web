import {
  concatMap,
  interval,
  merge,
  Observable,
  of,
  Subject,
  throwError,
} from "rxjs";
import { CiProcessExecutionDetailsComponent } from "./ci-process-execution-details.component";
import { CiProcessActions } from "../../state";
import { CiProcessExecutionAction } from "../state";
import { getCiProcessExecution } from "../state/ci-process-execution.selector";
import { Store } from "@ngrx/store";
import { ActivatedRoute, Params, Router } from "@angular/router";
import {
  ProjectIdRouteParamsResolverService,
  ProjectService,
} from "@mxflow/features/project";
import {
  fakeAsync,
  TestBed,
  tick,
  ComponentFixture,
} from "@angular/core/testing";
import {
  BuildAndTestProcessExecution,
  BuildAndTestProcessExecutionMapperService,
} from "@mxflow/features/business-process";
import { BuildAndTestExecutionFetcherService } from "@mxevolve/domains/business-process/data-access";
import { CiProcessStageSelectorService } from "../service/ci-process-stage-selector.service";

const CI_PROCESS_EXECUTION_ID = "ciProcessId";
const PROJECT_ID = "projectId";

describe("Build and test process execution details", () => {
  let fixture: ComponentFixture<CiProcessExecutionDetailsComponent>;
  let component: CiProcessExecutionDetailsComponent;
  let activatedRoute: ActivatedRoute;
  let router: Router;
  let ciProcessMapper: BuildAndTestProcessExecutionMapperService;
  let store: Store;
  let stageSelectorService: CiProcessStageSelectorService;
  let projectIdResolver: ProjectIdRouteParamsResolverService;
  let projectService: ProjectService;
  let domainExecutionFetcher: BuildAndTestExecutionFetcherService;

  beforeEach(() => {
    projectIdResolver = {
      resolve: jest.fn(() => PROJECT_ID),
    } as unknown as ProjectIdRouteParamsResolverService;

    activatedRoute = {
      params: of({ executionId: CI_PROCESS_EXECUTION_ID }),
    } as unknown as ActivatedRoute;

    stageSelectorService = {
      getWantedStage: jest.fn(),
    } as unknown as CiProcessStageSelectorService;

    ciProcessMapper = {
      toExecutionStages: jest.fn(),
      toStage: jest.fn(),
    } as unknown as BuildAndTestProcessExecutionMapperService;

    store = {
      dispatch: jest.fn(),
      pipe: jest.fn(),
      select: jest.fn().mockReturnValue(of({ name: "Mock Project" })),
    } as unknown as Store;

    router = {
      navigate: jest.fn(),
    } as unknown as Router;

    projectService = {
      getProjectById: jest.fn().mockReturnValue(of({ name: "Mock Project" })),
    } as unknown as ProjectService;

    domainExecutionFetcher = {
      fetchExecution: jest.fn().mockReturnValue(of({})),
    } as unknown as BuildAndTestExecutionFetcherService;

    TestBed.configureTestingModule({
      declarations: [CiProcessExecutionDetailsComponent],
      providers: [
        { provide: ActivatedRoute, useValue: activatedRoute },
        { provide: Router, useValue: router },
        { provide: Store, useValue: store },
        {
          provide: BuildAndTestProcessExecutionMapperService,
          useValue: ciProcessMapper,
        },
        {
          provide: CiProcessStageSelectorService,
          useValue: stageSelectorService,
        },
        {
          provide: ProjectIdRouteParamsResolverService,
          useValue: projectIdResolver,
        },
        {
          provide: BuildAndTestExecutionFetcherService,
          useValue: domainExecutionFetcher,
        },
      ],
    }).overrideComponent(CiProcessExecutionDetailsComponent, {
      set: {
        providers: [{ provide: ProjectService, useValue: projectService }],
      },
    });

    fixture = TestBed.createComponent(CiProcessExecutionDetailsComponent);
    component = fixture.componentInstance;
  });

  it("should fetch the ci process execution on init", () => {
    component.ngOnInit();

    expect(store.pipe).toHaveBeenCalledWith(getCiProcessExecution);
  });

  it("should throw error if failed to fetch execution", () => {
    let error = "error";
    jest.spyOn(store, "pipe").mockReturnValueOnce(throwError(() => error));

    component.ngOnInit();

    expect(store.dispatch).toHaveBeenCalledWith(
      CiProcessActions.updateErrorMessage({ message: error })
    );
  });

  it("should reload CI process execution correctly", () => {
    component.ngOnInit();
    component.refetchExecution();

    expect(store.dispatch).toHaveBeenCalledWith(
      CiProcessExecutionAction.getCiProcessExecution({
        id: CI_PROCESS_EXECUTION_ID,
        projectId: PROJECT_ID,
      })
    );
  });

  it("given a process with no stage that was started, when displaying the process details, then the user should be alerted", fakeAsync(() => {
    store.pipe = jest.fn().mockReturnValue(
      of({
        id: CI_PROCESS_EXECUTION_ID,
        createBranchStage: { startDate: null },
        prepareBuildStage: { startDate: null },
        buildAndTestStage: { startDate: null },
        integrateChangesStage: { startDate: null },
      } as unknown as BuildAndTestProcessExecution)
    );

    component.ngOnInit();

    tick();

    expect(component.notStarted).toBeTruthy();
  }));

  it("given a process with at least one stage that was started, when displaying the process details, then the user should not be alerted", fakeAsync(() => {
    store.pipe = jest.fn().mockReturnValue(
      of({
        id: CI_PROCESS_EXECUTION_ID,
        createBranchStage: { startDate: "2025-10-06T12:41:44.410455491Z" },
        prepareBuildStage: { startDate: null },
        buildAndTestStage: { startDate: null },
        integrateChangesStage: { startDate: null },
      } as unknown as BuildAndTestProcessExecution)
    );

    component.ngOnInit();

    tick();

    expect(component.notStarted).toBeFalsy();
  }));

  it("should unsubscribe to observables that outlive the component", () => {
    let observable1 = interval(100).pipe(
      concatMap((value) => value.toString())
    );
    let observable2 = interval(100).pipe(
      concatMap((value) => value.toString())
    );
    let subject = new Subject();

    let executionObservable = merge(subject, observable1);
    let executionIdObservable = merge(subject, observable2);

    jest.spyOn(store, "pipe").mockReturnValue(executionObservable);
    component.activatedRoute.params =
      executionIdObservable as unknown as Observable<Params>;

    component.ngOnInit();

    expect(subject.observed).toBe(true);

    component.ngOnDestroy();

    expect(subject.observed).toBe(false);
  });
});
