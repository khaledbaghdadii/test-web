import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { CiProcessComponent } from "./ci-process.component";
import { CiProcessRoutingModule } from "./ci-process-routing.module";
import { APP_CONFIG } from "@mxflow/config";
import {
  environment,
  EnvironmentProvider,
} from "../../environments/environment";
import { CiProcessExecutionModule } from "./ci-process-execution/ci-process-execution.module";
import { StoreModule } from "@ngrx/store";
import { ciProcessReducer } from "./state/ci-process.reducer";
import { ErrorAlertComponent } from "@mxflow/ui/alert";
import { CiProcessGlobalMessageComponent } from "./ci-process-global-message.component";
import { BusinessProcessExecutionService } from "@mxflow/features/business-process";

@NgModule({
  imports: [
    CommonModule,
    CiProcessRoutingModule,
    CiProcessExecutionModule,
    StoreModule.forFeature("ciProcess", ciProcessReducer),
    ErrorAlertComponent,
  ],
  declarations: [CiProcessComponent, CiProcessGlobalMessageComponent],
  providers: [
    EnvironmentProvider,
    { provide: APP_CONFIG, useValue: environment },
    BusinessProcessExecutionService,
  ],
})
export class CiProcessModule {}
